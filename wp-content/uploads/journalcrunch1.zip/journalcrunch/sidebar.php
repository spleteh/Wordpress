<!-- Begin #colRight -->
	<div id="colRight">
			<?php // Widgetized sidebar 
			if ( ! dynamic_sidebar( 'sidebar' ) ) :?>
			<div class="rightBox">
				<div class="rightBoxInner">
				<h2>WIDGETS NEEDED!</h2>
				<p>Go ahead and add some widgets here! Admin > Appearance > Widgets</p>
				</div>
			</div>
			<?php endif; ?>
	</div>
	
<!-- End #colRight -->